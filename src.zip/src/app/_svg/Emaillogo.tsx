import * as React from "react"
import { SVGProps } from "react"
const Emaillogo = (props: SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    fill=""
    viewBox="0 0 24 24"
    {...props}
  >
    <g stroke="#" strokeLinecap="round" strokeWidth={2}>
      <path strokeLinejoin="round" d="m4 7 6.2 4.65a3 3 0 0 0 3.6 0L20 7" />
      <rect width={18} height={14} x={3} y={5} rx={2} />
    </g>
  </svg>
)
export default Emaillogo
