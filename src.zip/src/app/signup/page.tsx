import SignupForm from "./_component/SignupForm";



const Page = () => {
 
  return (
    <div className="bg-black h flex items-center justify-center items center capitalize max-md:p-15 ">
      <SignupForm/>
    </div>
  );
};

export default Page;
