import LoginForm from "./_components/LoginForm";


// import Eye from "../_svg/eye";

const Login = () => {
  

  return (
    <div className="bg-black h-120 flex items-center justify-center items center  ">
     <LoginForm/>
    </div>
  );
};

export default Login;
